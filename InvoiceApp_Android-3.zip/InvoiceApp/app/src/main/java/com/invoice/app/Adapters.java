package com.invoice.app;

import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// ─── Items Adapter (editable, for NewInvoice) ───────────────
class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.VH> {
    List<InvoiceItem> items;
    Runnable onChange;

    ItemsAdapter(List<InvoiceItem> items, Runnable onChange) {
        this.items = items;
        this.onChange = onChange;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_invoice_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        InvoiceItem item = items.get(pos);
        h.tvName.setText(item.name);
        h.tvDetail.setText(String.format("%.0f × %.2f = %.2f ر.س", item.quantity, item.unitPrice, item.total));
        h.btnRemove.setOnClickListener(v -> {
            int p = h.getAdapterPosition();
            items.remove(p);
            notifyItemRemoved(p);
            onChange.run();
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvDetail;
        ImageButton btnRemove;
        VH(View v) {
            super(v);
            tvName = v.findViewById(R.id.tvItemName);
            tvDetail = v.findViewById(R.id.tvItemDetail);
            btnRemove = v.findViewById(R.id.btnRemoveItem);
        }
    }
}

// ─── Items View Adapter (read-only, for Detail) ─────────────
class ItemsViewAdapter extends RecyclerView.Adapter<ItemsViewAdapter.VH> {
    List<InvoiceItem> items;

    ItemsViewAdapter(List<InvoiceItem> items) { this.items = items; }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_invoice_view_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        InvoiceItem item = items.get(pos);
        h.tvName.setText(item.name);
        h.tvQty.setText(String.format("%.0f", item.quantity));
        h.tvPrice.setText(String.format("%.2f", item.unitPrice));
        h.tvTotal.setText(String.format("%.2f", item.total));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvQty, tvPrice, tvTotal;
        VH(View v) {
            super(v);
            tvName = v.findViewById(R.id.tvItemName);
            tvQty = v.findViewById(R.id.tvItemQty);
            tvPrice = v.findViewById(R.id.tvItemPrice);
            tvTotal = v.findViewById(R.id.tvItemTotal);
        }
    }
}

// ─── Invoice List Adapter ────────────────────────────────────
class InvoiceListAdapter extends RecyclerView.Adapter<InvoiceListAdapter.VH> {
    List<Invoice> invoices;
    OnInvoiceClick listener;

    interface OnInvoiceClick { void onClick(Invoice inv); }

    InvoiceListAdapter(List<Invoice> invoices, OnInvoiceClick listener) {
        this.invoices = invoices;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_invoice_list, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Invoice inv = invoices.get(pos);
        h.tvNum.setText(inv.invoiceNumber);
        h.tvClient.setText(inv.clientName);
        h.tvDate.setText(inv.date);
        h.tvTotal.setText(String.format("%.2f ر.س", inv.total));
        h.tvStatus.setText(inv.status);
        h.tvStatus.setBackgroundResource("مدفوعة".equals(inv.status)
                ? R.drawable.badge_paid : R.drawable.badge_draft);
        h.itemView.setOnClickListener(v -> listener.onClick(inv));
    }

    @Override
    public int getItemCount() { return invoices.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvNum, tvClient, tvDate, tvTotal, tvStatus;
        VH(View v) {
            super(v);
            tvNum = v.findViewById(R.id.tvInvNum);
            tvClient = v.findViewById(R.id.tvClient);
            tvDate = v.findViewById(R.id.tvDate);
            tvTotal = v.findViewById(R.id.tvTotal);
            tvStatus = v.findViewById(R.id.tvStatus);
        }
    }
}
