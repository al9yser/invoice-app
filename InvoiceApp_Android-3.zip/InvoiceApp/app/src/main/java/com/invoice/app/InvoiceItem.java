package com.invoice.app;

public class InvoiceItem {
    public long id;
    public String name;
    public double quantity;
    public double unitPrice;
    public double total;

    public InvoiceItem() {}

    public InvoiceItem(String name, double quantity, double unitPrice) {
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.total = quantity * unitPrice;
    }
}
