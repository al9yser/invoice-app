package com.invoice.app;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.*;

public class NewInvoiceActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText etClientName, etClientPhone, etClientAddress, etNotes, etDiscount, etTax;
    TextView tvDate, tvInvoiceNumber;
    RecyclerView rvItems;
    ItemsAdapter adapter;
    List<InvoiceItem> items = new ArrayList<>();
    TextView tvSubtotal, tvTaxAmount, tvDiscountAmount, tvTotal;
    String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_invoice);

        db = new DatabaseHelper(this);

        etClientName = findViewById(R.id.etClientName);
        etClientPhone = findViewById(R.id.etClientPhone);
        etClientAddress = findViewById(R.id.etClientAddress);
        etNotes = findViewById(R.id.etNotes);
        etDiscount = findViewById(R.id.etDiscount);
        etTax = findViewById(R.id.etTax);
        tvDate = findViewById(R.id.tvDate);
        tvInvoiceNumber = findViewById(R.id.tvInvoiceNumber);
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvTaxAmount = findViewById(R.id.tvTaxAmount);
        tvDiscountAmount = findViewById(R.id.tvDiscountAmount);
        tvTotal = findViewById(R.id.tvTotal);
        rvItems = findViewById(R.id.rvItems);

        // Set defaults
        String invNum = db.getNextInvoiceNumber();
        tvInvoiceNumber.setText(invNum);

        selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        tvDate.setText(selectedDate);

        String taxRate = db.getSetting("tax_rate");
        etTax.setText(taxRate.isEmpty() ? "15" : taxRate);

        // Setup items RecyclerView
        adapter = new ItemsAdapter(items, this::updateTotals);
        rvItems.setLayoutManager(new LinearLayoutManager(this));
        rvItems.setAdapter(adapter);

        // Date picker
        tvDate.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            new DatePickerDialog(this, (view, y, m, d) -> {
                selectedDate = String.format("%04d-%02d-%02d", y, m + 1, d);
                tvDate.setText(selectedDate);
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });

        // Add item button
        findViewById(R.id.btnAddItem).setOnClickListener(v -> showAddItemDialog());

        // Save button
        findViewById(R.id.btnSave).setOnClickListener(v -> saveInvoice());

        // Tax/Discount listeners
        etTax.addTextChangedListener(new SimpleTextWatcher(s -> updateTotals()));
        etDiscount.addTextChangedListener(new SimpleTextWatcher(s -> updateTotals()));

        // Back
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        updateTotals();
    }

    void showAddItemDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        EditText etName = view.findViewById(R.id.etItemName);
        EditText etQty = view.findViewById(R.id.etItemQty);
        EditText etPrice = view.findViewById(R.id.etItemPrice);

        new AlertDialog.Builder(this)
                .setTitle("إضافة منتج / خدمة")
                .setView(view)
                .setPositiveButton("إضافة", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    String qtyStr = etQty.getText().toString().trim();
                    String priceStr = etPrice.getText().toString().trim();

                    if (name.isEmpty() || qtyStr.isEmpty() || priceStr.isEmpty()) {
                        Toast.makeText(this, "يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double qty = Double.parseDouble(qtyStr);
                    double price = Double.parseDouble(priceStr);
                    items.add(new InvoiceItem(name, qty, price));
                    adapter.notifyItemInserted(items.size() - 1);
                    updateTotals();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    void updateTotals() {
        double subtotal = 0;
        for (InvoiceItem item : items) subtotal += item.total;

        double taxPct = parseDouble(etTax.getText().toString());
        double discountPct = parseDouble(etDiscount.getText().toString());

        double taxAmt = subtotal * (taxPct / 100.0);
        double discAmt = subtotal * (discountPct / 100.0);
        double grand = subtotal + taxAmt - discAmt;

        tvSubtotal.setText(String.format("%.2f ر.س", subtotal));
        tvTaxAmount.setText(String.format("%.2f ر.س", taxAmt));
        tvDiscountAmount.setText(String.format("%.2f ر.س", discAmt));
        tvTotal.setText(String.format("%.2f ر.س", grand));
    }

    void saveInvoice() {
        if (etClientName.getText().toString().trim().isEmpty()) {
            etClientName.setError("يرجى إدخال اسم العميل");
            etClientName.requestFocus();
            return;
        }
        if (items.isEmpty()) {
            Toast.makeText(this, "يرجى إضافة منتج واحد على الأقل", Toast.LENGTH_SHORT).show();
            return;
        }

        Invoice inv = new Invoice();
        inv.invoiceNumber = tvInvoiceNumber.getText().toString();
        inv.clientName = etClientName.getText().toString().trim();
        inv.clientPhone = etClientPhone.getText().toString().trim();
        inv.clientAddress = etClientAddress.getText().toString().trim();
        inv.date = selectedDate;
        inv.tax = parseDouble(etTax.getText().toString());
        inv.discount = parseDouble(etDiscount.getText().toString());
        inv.notes = etNotes.getText().toString().trim();
        inv.status = "مسودة";
        inv.items = items;
        inv.total = inv.getGrandTotal();

        long id = db.insertInvoice(inv);

        Intent intent = new Intent(this, InvoiceDetailActivity.class);
        intent.putExtra("invoice_id", id);
        startActivity(intent);
        finish();
    }

    double parseDouble(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }
}
