package com.invoice.app;

import java.util.ArrayList;
import java.util.List;

public class Invoice {
    public long id;
    public String invoiceNumber;
    public String clientName;
    public String clientPhone;
    public String clientAddress;
    public String date;
    public double total;
    public double tax;
    public double discount;
    public String notes;
    public String status;
    public List<InvoiceItem> items = new ArrayList<>();

    public double getSubtotal() {
        double sub = 0;
        for (InvoiceItem item : items) sub += item.total;
        return sub;
    }

    public double getTaxAmount() {
        return getSubtotal() * (tax / 100.0);
    }

    public double getDiscountAmount() {
        return getSubtotal() * (discount / 100.0);
    }

    public double getGrandTotal() {
        return getSubtotal() + getTaxAmount() - getDiscountAmount();
    }
}
