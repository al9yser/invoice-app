package com.invoice.app;

import android.text.Editable;
import android.text.TextWatcher;

public class SimpleTextWatcher implements TextWatcher {
    interface OnChange { void onChange(String s); }
    OnChange cb;
    SimpleTextWatcher(OnChange cb) { this.cb = cb; }
    public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
    public void onTextChanged(CharSequence s, int st, int b, int c) { cb.onChange(s.toString()); }
    public void afterTextChanged(Editable s) {}
}
