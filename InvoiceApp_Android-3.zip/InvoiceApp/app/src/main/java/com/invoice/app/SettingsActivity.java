package com.invoice.app;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText etCompanyName, etCompanyPhone, etCompanyAddress, etTaxRate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        db = new DatabaseHelper(this);

        etCompanyName = findViewById(R.id.etCompanyName);
        etCompanyPhone = findViewById(R.id.etCompanyPhone);
        etCompanyAddress = findViewById(R.id.etCompanyAddress);
        etTaxRate = findViewById(R.id.etTaxRate);

        // Load existing settings
        etCompanyName.setText(db.getSetting("company_name"));
        etCompanyPhone.setText(db.getSetting("company_phone"));
        etCompanyAddress.setText(db.getSetting("company_address"));
        etTaxRate.setText(db.getSetting("tax_rate"));

        findViewById(R.id.btnSave).setOnClickListener(v -> saveSettings());
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    void saveSettings() {
        db.setSetting("company_name", etCompanyName.getText().toString().trim());
        db.setSetting("company_phone", etCompanyPhone.getText().toString().trim());
        db.setSetting("company_address", etCompanyAddress.getText().toString().trim());
        db.setSetting("tax_rate", etTaxRate.getText().toString().trim());
        Toast.makeText(this, "تم حفظ الإعدادات ✓", Toast.LENGTH_SHORT).show();
        finish();
    }
}
