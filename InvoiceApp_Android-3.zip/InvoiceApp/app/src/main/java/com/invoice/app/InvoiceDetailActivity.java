package com.invoice.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.*;
import java.util.List;

public class InvoiceDetailActivity extends AppCompatActivity {

    DatabaseHelper db;
    Invoice invoice;
    TextView tvInvNum, tvDate, tvClient, tvPhone, tvAddress, tvStatus;
    TextView tvSubtotal, tvTax, tvDiscount, tvTotal, tvNotes;
    RecyclerView rvItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_detail);

        db = new DatabaseHelper(this);
        long id = getIntent().getLongExtra("invoice_id", -1);
        if (id == -1) { finish(); return; }

        invoice = db.getInvoice(id);

        tvInvNum = findViewById(R.id.tvInvNum);
        tvDate = findViewById(R.id.tvDate);
        tvClient = findViewById(R.id.tvClient);
        tvPhone = findViewById(R.id.tvPhone);
        tvAddress = findViewById(R.id.tvAddress);
        tvStatus = findViewById(R.id.tvStatus);
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvTax = findViewById(R.id.tvTax);
        tvDiscount = findViewById(R.id.tvDiscount);
        tvTotal = findViewById(R.id.tvTotal);
        tvNotes = findViewById(R.id.tvNotes);
        rvItems = findViewById(R.id.rvItems);

        populateViews();

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnShare).setOnClickListener(v -> shareInvoice());
        findViewById(R.id.btnDelete).setOnClickListener(v -> confirmDelete());
        findViewById(R.id.btnMarkPaid).setOnClickListener(v -> markAsPaid());
    }

    void populateViews() {
        tvInvNum.setText(invoice.invoiceNumber);
        tvDate.setText(invoice.date);
        tvClient.setText(invoice.clientName);
        tvPhone.setText(invoice.clientPhone.isEmpty() ? "—" : invoice.clientPhone);
        tvAddress.setText(invoice.clientAddress.isEmpty() ? "—" : invoice.clientAddress);
        tvStatus.setText(invoice.status);
        tvSubtotal.setText(String.format("%.2f ر.س", invoice.getSubtotal()));
        tvTax.setText(String.format("%.2f ر.س (%.0f%%)", invoice.getTaxAmount(), invoice.tax));
        tvDiscount.setText(String.format("%.2f ر.س (%.0f%%)", invoice.getDiscountAmount(), invoice.discount));
        tvTotal.setText(String.format("%.2f ر.س", invoice.getGrandTotal()));
        tvNotes.setText(invoice.notes.isEmpty() ? "لا توجد ملاحظات" : invoice.notes);

        if ("مدفوعة".equals(invoice.status)) {
            tvStatus.setBackgroundResource(R.drawable.badge_paid);
        } else {
            tvStatus.setBackgroundResource(R.drawable.badge_draft);
        }

        ItemsViewAdapter adapter = new ItemsViewAdapter(invoice.items);
        rvItems.setLayoutManager(new LinearLayoutManager(this));
        rvItems.setAdapter(adapter);
    }

    void shareInvoice() {
        String text = buildInvoiceText();
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, text);
        share.putExtra(Intent.EXTRA_SUBJECT, "فاتورة " + invoice.invoiceNumber);
        startActivity(Intent.createChooser(share, "مشاركة الفاتورة"));
    }

    String buildInvoiceText() {
        String company = db.getSetting("company_name");
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════\n");
        sb.append("       فاتورة ضريبية\n");
        sb.append("═══════════════════\n");
        sb.append("الشركة: ").append(company).append("\n");
        sb.append("───────────────────\n");
        sb.append("رقم الفاتورة: ").append(invoice.invoiceNumber).append("\n");
        sb.append("التاريخ: ").append(invoice.date).append("\n");
        sb.append("العميل: ").append(invoice.clientName).append("\n");
        if (!invoice.clientPhone.isEmpty())
            sb.append("الهاتف: ").append(invoice.clientPhone).append("\n");
        sb.append("───────────────────\n");
        sb.append("البنود:\n");
        for (InvoiceItem item : invoice.items) {
            sb.append(String.format("• %s\n  %s × %.2f = %.2f ر.س\n",
                    item.name, item.quantity, item.unitPrice, item.total));
        }
        sb.append("───────────────────\n");
        sb.append(String.format("المجموع الفرعي: %.2f ر.س\n", invoice.getSubtotal()));
        if (invoice.tax > 0)
            sb.append(String.format("الضريبة (%.0f%%): %.2f ر.س\n", invoice.tax, invoice.getTaxAmount()));
        if (invoice.discount > 0)
            sb.append(String.format("الخصم (%.0f%%): %.2f ر.س\n", invoice.discount, invoice.getDiscountAmount()));
        sb.append(String.format("الإجمالي: %.2f ر.س\n", invoice.getGrandTotal()));
        if (!invoice.notes.isEmpty())
            sb.append("ملاحظات: ").append(invoice.notes).append("\n");
        sb.append("═══════════════════");
        return sb.toString();
    }

    void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("حذف الفاتورة")
                .setMessage("هل أنت متأكد من حذف الفاتورة " + invoice.invoiceNumber + "؟")
                .setPositiveButton("حذف", (d, w) -> {
                    db.deleteInvoice(invoice.id);
                    Toast.makeText(this, "تم حذف الفاتورة", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    void markAsPaid() {
        // Update status in DB
        android.content.ContentValues cv = new android.content.ContentValues();
        cv.put("status", "مدفوعة");
        db.getWritableDatabase().update(DatabaseHelper.TABLE_INVOICES, cv,
                DatabaseHelper.COL_ID + "=?", new String[]{String.valueOf(invoice.id)});
        invoice.status = "مدفوعة";
        tvStatus.setText("مدفوعة");
        tvStatus.setBackgroundResource(R.drawable.badge_paid);
        Toast.makeText(this, "تم تحديث الحالة إلى مدفوعة", Toast.LENGTH_SHORT).show();
    }
}
