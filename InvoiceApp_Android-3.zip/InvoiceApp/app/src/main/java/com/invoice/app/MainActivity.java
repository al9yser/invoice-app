package com.invoice.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    TextView tvCompanyName, tvTotalInvoices, tvTotalRevenue, tvPending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        tvCompanyName = findViewById(R.id.tvCompanyName);
        tvTotalInvoices = findViewById(R.id.tvTotalInvoices);
        tvTotalRevenue = findViewById(R.id.tvTotalRevenue);
        tvPending = findViewById(R.id.tvPending);

        CardView cardNew = findViewById(R.id.cardNew);
        CardView cardList = findViewById(R.id.cardList);
        CardView cardSettings = findViewById(R.id.cardSettings);

        cardNew.setOnClickListener(v -> startActivity(new Intent(this, NewInvoiceActivity.class)));
        cardList.setOnClickListener(v -> startActivity(new Intent(this, InvoiceListActivity.class)));
        cardSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStats();
    }

    void refreshStats() {
        String company = db.getSetting("company_name");
        tvCompanyName.setText(company.isEmpty() ? "نظام الفواتير" : company);

        List<Invoice> invoices = db.getAllInvoices();
        tvTotalInvoices.setText(String.valueOf(invoices.size()));

        double total = 0;
        int pending = 0;
        for (Invoice inv : invoices) {
            total += inv.total;
            if ("مسودة".equals(inv.status)) pending++;
        }
        tvTotalRevenue.setText(String.format("%.2f ر.س", total));
        tvPending.setText(String.valueOf(pending));
    }
}
