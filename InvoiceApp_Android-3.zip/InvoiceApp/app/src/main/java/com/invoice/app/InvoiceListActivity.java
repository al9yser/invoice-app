package com.invoice.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InvoiceListActivity extends AppCompatActivity {

    DatabaseHelper db;
    RecyclerView rvInvoices;
    InvoiceListAdapter adapter;
    List<Invoice> allInvoices = new ArrayList<>();
    List<Invoice> filteredInvoices = new ArrayList<>();
    EditText etSearch;
    TextView tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_list);

        db = new DatabaseHelper(this);
        rvInvoices = findViewById(R.id.rvInvoices);
        etSearch = findViewById(R.id.etSearch);
        tvEmpty = findViewById(R.id.tvEmpty);

        adapter = new InvoiceListAdapter(filteredInvoices, invoice -> {
            Intent intent = new Intent(this, InvoiceDetailActivity.class);
            intent.putExtra("invoice_id", invoice.id);
            startActivity(intent);
        });

        rvInvoices.setLayoutManager(new LinearLayoutManager(this));
        rvInvoices.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { filterInvoices(s.toString()); }
            public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.fabNew).setOnClickListener(v ->
                startActivity(new Intent(this, NewInvoiceActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        allInvoices = db.getAllInvoices();
        filterInvoices(etSearch.getText().toString());
    }

    void filterInvoices(String query) {
        filteredInvoices.clear();
        for (Invoice inv : allInvoices) {
            if (query.isEmpty() ||
                    inv.clientName.contains(query) ||
                    inv.invoiceNumber.contains(query)) {
                filteredInvoices.add(inv);
            }
        }
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(filteredInvoices.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
