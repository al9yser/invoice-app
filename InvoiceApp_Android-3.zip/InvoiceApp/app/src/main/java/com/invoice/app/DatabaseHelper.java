package com.invoice.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "invoices.db";
    private static final int DB_VERSION = 1;

    // Invoices table
    public static final String TABLE_INVOICES = "invoices";
    public static final String COL_ID = "id";
    public static final String COL_INVOICE_NUMBER = "invoice_number";
    public static final String COL_CLIENT_NAME = "client_name";
    public static final String COL_CLIENT_PHONE = "client_phone";
    public static final String COL_CLIENT_ADDRESS = "client_address";
    public static final String COL_DATE = "date";
    public static final String COL_TOTAL = "total";
    public static final String COL_TAX = "tax";
    public static final String COL_DISCOUNT = "discount";
    public static final String COL_NOTES = "notes";
    public static final String COL_STATUS = "status";

    // Items table
    public static final String TABLE_ITEMS = "invoice_items";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_INVOICE_ID = "invoice_id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_PRICE = "unit_price";
    public static final String COL_ITEM_TOTAL = "item_total";

    // Settings table
    public static final String TABLE_SETTINGS = "settings";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_INVOICES + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_INVOICE_NUMBER + " TEXT, " +
                COL_CLIENT_NAME + " TEXT, " +
                COL_CLIENT_PHONE + " TEXT, " +
                COL_CLIENT_ADDRESS + " TEXT, " +
                COL_DATE + " TEXT, " +
                COL_TOTAL + " REAL, " +
                COL_TAX + " REAL DEFAULT 0, " +
                COL_DISCOUNT + " REAL DEFAULT 0, " +
                COL_NOTES + " TEXT, " +
                COL_STATUS + " TEXT DEFAULT 'مسودة'" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_INVOICE_ID + " INTEGER, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_QTY + " REAL, " +
                COL_ITEM_PRICE + " REAL, " +
                COL_ITEM_TOTAL + " REAL, " +
                "FOREIGN KEY(" + COL_INVOICE_ID + ") REFERENCES " + TABLE_INVOICES + "(" + COL_ID + ")" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_SETTINGS + " (" +
                "key TEXT PRIMARY KEY, " +
                "value TEXT" +
                ")");

        // Default settings
        db.execSQL("INSERT INTO " + TABLE_SETTINGS + " VALUES ('company_name', 'شركتي')");
        db.execSQL("INSERT INTO " + TABLE_SETTINGS + " VALUES ('company_phone', '')");
        db.execSQL("INSERT INTO " + TABLE_SETTINGS + " VALUES ('company_address', '')");
        db.execSQL("INSERT INTO " + TABLE_SETTINGS + " VALUES ('tax_rate', '15')");
        db.execSQL("INSERT INTO " + TABLE_SETTINGS + " VALUES ('invoice_counter', '1')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVOICES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);
        onCreate(db);
    }

    // ─── Invoice CRUD ───────────────────────────────────────────

    public long insertInvoice(Invoice invoice) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_INVOICE_NUMBER, invoice.invoiceNumber);
        cv.put(COL_CLIENT_NAME, invoice.clientName);
        cv.put(COL_CLIENT_PHONE, invoice.clientPhone);
        cv.put(COL_CLIENT_ADDRESS, invoice.clientAddress);
        cv.put(COL_DATE, invoice.date);
        cv.put(COL_TOTAL, invoice.total);
        cv.put(COL_TAX, invoice.tax);
        cv.put(COL_DISCOUNT, invoice.discount);
        cv.put(COL_NOTES, invoice.notes);
        cv.put(COL_STATUS, invoice.status);
        long id = db.insert(TABLE_INVOICES, null, cv);

        for (InvoiceItem item : invoice.items) {
            ContentValues icv = new ContentValues();
            icv.put(COL_INVOICE_ID, id);
            icv.put(COL_ITEM_NAME, item.name);
            icv.put(COL_ITEM_QTY, item.quantity);
            icv.put(COL_ITEM_PRICE, item.unitPrice);
            icv.put(COL_ITEM_TOTAL, item.total);
            db.insert(TABLE_ITEMS, null, icv);
        }
        return id;
    }

    public List<Invoice> getAllInvoices() {
        List<Invoice> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_INVOICES, null, null, null, null, null, COL_ID + " DESC");
        while (c.moveToNext()) {
            Invoice inv = cursorToInvoice(c);
            list.add(inv);
        }
        c.close();
        return list;
    }

    public Invoice getInvoice(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_INVOICES, null, COL_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
        Invoice inv = null;
        if (c.moveToFirst()) {
            inv = cursorToInvoice(c);
            inv.items = getItemsForInvoice(id);
        }
        c.close();
        return inv;
    }

    public List<InvoiceItem> getItemsForInvoice(long invoiceId) {
        List<InvoiceItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_ITEMS, null, COL_INVOICE_ID + "=?",
                new String[]{String.valueOf(invoiceId)}, null, null, null);
        while (c.moveToNext()) {
            InvoiceItem item = new InvoiceItem();
            item.id = c.getLong(c.getColumnIndexOrThrow(COL_ITEM_ID));
            item.name = c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME));
            item.quantity = c.getDouble(c.getColumnIndexOrThrow(COL_ITEM_QTY));
            item.unitPrice = c.getDouble(c.getColumnIndexOrThrow(COL_ITEM_PRICE));
            item.total = c.getDouble(c.getColumnIndexOrThrow(COL_ITEM_TOTAL));
            items.add(item);
        }
        c.close();
        return items;
    }

    public void deleteInvoice(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_ITEMS, COL_INVOICE_ID + "=?", new String[]{String.valueOf(id)});
        db.delete(TABLE_INVOICES, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // ─── Settings ───────────────────────────────────────────────

    public String getSetting(String key) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_SETTINGS, new String[]{"value"}, "key=?", new String[]{key}, null, null, null);
        String val = "";
        if (c.moveToFirst()) val = c.getString(0);
        c.close();
        return val;
    }

    public void setSetting(String key, String value) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("key", key);
        cv.put("value", value);
        db.insertOrReplace(TABLE_SETTINGS, null, cv);
    }

    public String getNextInvoiceNumber() {
        int counter = Integer.parseInt(getSetting("invoice_counter"));
        String num = String.format("INV-%04d", counter);
        setSetting("invoice_counter", String.valueOf(counter + 1));
        return num;
    }

    private Invoice cursorToInvoice(Cursor c) {
        Invoice inv = new Invoice();
        inv.id = c.getLong(c.getColumnIndexOrThrow(COL_ID));
        inv.invoiceNumber = c.getString(c.getColumnIndexOrThrow(COL_INVOICE_NUMBER));
        inv.clientName = c.getString(c.getColumnIndexOrThrow(COL_CLIENT_NAME));
        inv.clientPhone = c.getString(c.getColumnIndexOrThrow(COL_CLIENT_PHONE));
        inv.clientAddress = c.getString(c.getColumnIndexOrThrow(COL_CLIENT_ADDRESS));
        inv.date = c.getString(c.getColumnIndexOrThrow(COL_DATE));
        inv.total = c.getDouble(c.getColumnIndexOrThrow(COL_TOTAL));
        inv.tax = c.getDouble(c.getColumnIndexOrThrow(COL_TAX));
        inv.discount = c.getDouble(c.getColumnIndexOrThrow(COL_DISCOUNT));
        inv.notes = c.getString(c.getColumnIndexOrThrow(COL_NOTES));
        inv.status = c.getString(c.getColumnIndexOrThrow(COL_STATUS));
        return inv;
    }
}
